// @polsia:user-owned — configure the home page in src/lib/business/landing/config.ts.
import type { Metadata } from 'next';
import Link from 'next/link';
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Check,
  Clock3,
  PackageCheck,
  RefreshCw,
  ShieldAlert,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { siteDescription, siteName } from '@/lib/brand';

export const metadata: Metadata = {
  title: { absolute: `${siteName} — ${siteDescription}` },
  description: siteDescription,
  alternates: { canonical: '/' },
};

const workflow = [
  {
    number: '01',
    title: 'Watch availability',
    description:
    'Stockwake’s AI-powered monitor checks product availability around the clock, keeping an eye on the items behind your campaigns.',
    icon: Clock3,
  },
  {
    number: '02',
    title: 'Pause when stock runs out',
    description:
      'When an item goes out of stock, its connected ads are automatically paused before they keep sending shoppers to an unavailable product.',
    icon: ShieldAlert,
  },
  {
    number: '03',
    title: 'Resume when it returns',
    description:
      'When inventory is back, Stockwake resumes the connected ads so products can be promoted again.',
    icon: RefreshCw,
  },
];

export default function HomePage() {
  return (
    <main className="overflow-hidden">
      <section className="relative isolate mx-auto grid max-w-screen-xl items-center gap-12 px-gutter py-16 sm:py-20 lg:grid-cols-[0.92fr_1.08fr] lg:gap-10 lg:py-28">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-24 -top-24 -z-10 size-[28rem] rounded-full bg-primary/10 blur-3xl"
        />
        <div className="max-w-2xl motion-safe:animate-in motion-safe:fade-in motion-safe:slide-in-from-bottom-4 motion-safe:duration-700">
          <div className="mb-7 flex items-center gap-3 text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
            <span className="h-px w-8 bg-primary" />
            Stockwake <span className="text-border">/</span> AI-powered inventory-to-ad control
          </div>
          <h1 className="max-w-[12ch] text-5xl font-semibold leading-[0.98] tracking-[-0.055em] text-foreground sm:text-6xl lg:text-7xl">
            Keep out-of-stock products <span className="text-primary">out of your ads.</span>
          </h1>
          <p className="mt-7 max-w-xl text-lg leading-relaxed text-muted-foreground sm:text-xl">
            Stockwake’s AI-powered monitor watches what is available in your shop and pauses
            connected ads when an item sells out. When inventory returns, Stockwake resumes those
            ads.
          </p>
          <div className="mt-9 flex flex-wrap items-center gap-3">
            <Button
              asChild
              size="lg"
              className="group h-12 rounded-sm px-6 text-sm transition duration-200 ease-out hover:-translate-y-0.5"
            >
              <Link href="#how-it-works">
                See how it works
                <ArrowDownRight className="transition-transform duration-200 group-hover:translate-x-0.5 group-hover:translate-y-0.5" />
              </Link>
            </Button>
            <Button
              asChild
              variant="ghost"
              size="lg"
              className="h-12 rounded-sm px-4 text-sm text-foreground transition duration-200 ease-out hover:translate-x-0.5"
            >
              <Link href="mailto:stockwake-wgwcxq@polsia.app">
                Talk to Stockwake <ArrowUpRight />
              </Link>
            </Button>
          </div>
          <div className="mt-8 flex items-center gap-2 text-sm text-muted-foreground">
            <Check className="size-4 text-primary" aria-hidden="true" />
            <span>Always-on checks. A daily record of changes and actions.</span>
          </div>
        </div>

        <figure className="relative mx-auto w-full max-w-2xl motion-safe:animate-in motion-safe:fade-in motion-safe:slide-in-from-bottom-6 motion-safe:duration-700 motion-safe:delay-150">
          <div
            aria-hidden="true"
            className="absolute -bottom-8 -left-8 -z-10 h-2/3 w-2/3 bg-gradient-to-br from-primary/15 via-muted/40 to-background"
          />
          <Card className="overflow-hidden rounded-sm border-border/80 bg-card shadow-xl shadow-primary/10">
            <CardHeader className="flex flex-row items-center justify-between gap-4 border-b border-border bg-muted/40 px-5 py-4 sm:px-6">
              <div className="flex items-center gap-3">
                <div className="flex size-9 items-center justify-center rounded-sm bg-primary text-primary-foreground">
                  <PackageCheck className="size-5" aria-hidden="true" />
                </div>
                <div>
                  <CardTitle className="text-sm font-semibold tracking-tight">Stockwake monitor</CardTitle>
                  <p className="mt-1 text-xs text-muted-foreground">Illustrative activity</p>
                </div>
              </div>
              <Badge
                variant="outline"
                className="gap-2 rounded-sm border-primary/30 bg-primary/10 px-2.5 py-1 text-[10px] uppercase tracking-[0.12em] text-primary"
              >
                <span className="size-1.5 rounded-full bg-primary motion-safe:animate-pulse motion-reduce:animate-none" />
                Monitoring
              </Badge>
            </CardHeader>
            <CardContent className="p-5 sm:p-7">
              <div className="flex flex-wrap items-end justify-between gap-3 border-b border-border pb-5">
                <div>
                  <p className="text-xs font-medium uppercase tracking-[0.15em] text-muted-foreground">
                    Inventory signals
                  </p>
                  <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">
                    Ads follow stock.
                  </p>
                </div>
                <span className="text-xs text-muted-foreground">Connected products</span>
              </div>

              <div className="relative mt-6 space-y-0">
                <div aria-hidden="true" className="absolute bottom-8 left-[1.15rem] top-8 w-px bg-border" />
                <div className="relative flex gap-4 py-3">
                  <div className="z-10 flex size-9 shrink-0 items-center justify-center rounded-full border border-border bg-card text-primary">
                    <ShieldAlert className="size-4" aria-hidden="true" />
                  </div>
                  <div className="min-w-0 flex-1 border-b border-border pb-5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="font-medium text-foreground">Product goes out of stock</p>
                      <Badge variant="secondary" className="rounded-sm text-[10px] uppercase tracking-wider">
                        Unavailable
                      </Badge>
                    </div>
                    <p className="mt-1.5 text-sm text-muted-foreground">
                      Connected ads are automatically paused.
                    </p>
                  </div>
                </div>
                <div className="relative flex gap-4 py-3">
                  <div className="z-10 flex size-9 shrink-0 items-center justify-center rounded-full border border-border bg-card text-primary">
                    <RefreshCw className="size-4" aria-hidden="true" />
                  </div>
                  <div className="min-w-0 flex-1 pt-1">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="font-medium text-foreground">Inventory returns</p>
                      <Badge variant="outline" className="rounded-sm text-[10px] uppercase tracking-wider">
                        In stock
                      </Badge>
                    </div>
                    <p className="mt-1.5 text-sm text-muted-foreground">
                      Connected ads are resumed.
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex items-center justify-between border-t border-border pt-4 text-xs text-muted-foreground">
                <span>Stock change → ad action</span>
                <span className="inline-flex items-center gap-1.5">
                  Built to stay in sync <ArrowRight className="size-3.5" aria-hidden="true" />
                </span>
              </div>
            </CardContent>
          </Card>
          <figcaption className="mt-3 text-right text-xs text-muted-foreground">
            Example workflow, shown for illustration.
          </figcaption>
        </figure>
      </section>

      <section id="how-it-works" className="scroll-mt-20 border-y border-border bg-muted/35">
        <div className="mx-auto grid max-w-screen-xl gap-12 px-gutter py-16 sm:py-20 lg:grid-cols-[0.78fr_1.22fr] lg:gap-20 lg:py-24">
          <div className="max-w-lg">
            <p className="mb-5 text-xs font-semibold uppercase tracking-[0.18em] text-primary">
              A tighter feedback loop
            </p>
            <h2 className="text-4xl font-semibold leading-[1.04] tracking-[-0.045em] text-foreground sm:text-5xl">
              Let inventory call the next move.
            </h2>
            <p className="mt-6 text-base leading-relaxed text-muted-foreground sm:text-lg">
              An unavailable product should not keep consuming ad attention. Stockwake connects
              product availability to the ads promoting it, then responds as stock changes.
            </p>
          </div>

          <ol className="divide-y divide-border border-y border-border">
            {workflow.map(({ number, title, description, icon: Icon }) => (
              <li key={number} className="group grid gap-4 py-6 sm:grid-cols-[3.5rem_1fr_2.5rem] sm:items-start sm:gap-5 sm:py-7">
                <span className="pt-1 font-mono text-xs tracking-widest text-muted-foreground">{number}</span>
                <div>
                  <h3 className="text-xl font-semibold tracking-tight text-foreground">{title}</h3>
                  <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground sm:text-base">
                    {description}
                  </p>
                </div>
                <Icon
                  className="hidden size-5 text-primary transition-transform duration-200 ease-out group-hover:translate-x-1 sm:mt-1 sm:block"
                  aria-hidden="true"
                />
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section id="daily-report" className="scroll-mt-20 mx-auto grid max-w-screen-xl items-center gap-12 px-gutter py-16 sm:py-20 lg:grid-cols-[1fr_0.9fr] lg:gap-24 lg:py-28">
        <div className="max-w-xl">
          <p className="mb-5 text-xs font-semibold uppercase tracking-[0.18em] text-primary">
            A daily stock report
          </p>
          <h2 className="text-4xl font-semibold leading-[1.04] tracking-[-0.045em] text-foreground sm:text-5xl">
            Wake up to what changed.
          </h2>
          <p className="mt-6 text-base leading-relaxed text-muted-foreground sm:text-lg">
            Each day, get a report of stock changes and the ad actions taken. Know what went out,
            what came back, and how connected campaigns responded.
          </p>
          <Link
            href="#contact"
            className="mt-7 inline-flex items-center gap-2 text-sm font-semibold text-foreground underline decoration-primary/50 decoration-2 underline-offset-4 transition-colors duration-200 hover:text-primary"
          >
            Ask about daily reporting <ArrowRight className="size-4" aria-hidden="true" />
          </Link>
        </div>

        <Card className="overflow-hidden rounded-sm border-border bg-card shadow-lg">
          <CardHeader className="border-b border-border bg-muted/35 px-5 py-4 sm:px-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">
                  Stockwake / Daily summary
                </p>
                <CardTitle className="mt-2 text-lg tracking-tight">Stock changes & ad actions</CardTitle>
              </div>
              <Badge variant="outline" className="rounded-sm px-2.5 py-1 text-[10px] uppercase tracking-wider">
                Daily report
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="p-5 sm:p-6">
            <div className="space-y-0">
              <div className="flex items-start gap-4 border-b border-border py-4">
                <span className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-sm bg-muted text-muted-foreground">
                  <ShieldAlert className="size-4" aria-hidden="true" />
                </span>
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">Product out of stock</p>
                  <p className="mt-1 text-sm text-muted-foreground">Connected ads paused</p>
                </div>
                <Check className="mt-1 size-4 text-primary" aria-label="Action recorded" />
              </div>
              <div className="flex items-start gap-4 py-4">
                <span className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-sm bg-muted text-muted-foreground">
                  <RefreshCw className="size-4" aria-hidden="true" />
                </span>
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">Inventory available again</p>
                  <p className="mt-1 text-sm text-muted-foreground">Connected ads resumed</p>
                </div>
                <Check className="mt-1 size-4 text-primary" aria-label="Action recorded" />
              </div>
            </div>
            <div className="mt-2 flex items-center gap-2 border-t border-border pt-4 text-xs text-muted-foreground">
              <Clock3 className="size-3.5" aria-hidden="true" />
              <span>A clear record of stock changes and actions taken.</span>
            </div>
          </CardContent>
        </Card>
      </section>

      <section id="contact" className="scroll-mt-20 border-t border-border bg-primary text-primary-foreground">
        <div className="mx-auto flex max-w-screen-xl flex-col gap-8 px-gutter py-14 sm:flex-row sm:items-center sm:justify-between sm:py-16">
          <div className="max-w-2xl">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary-foreground/75">
              Stockwake
            </p>
            <h2 className="mt-3 text-3xl font-semibold tracking-[-0.04em] sm:text-4xl">
              Keep your ads in step with your stock.
            </h2>
            <p className="mt-3 max-w-xl text-sm leading-relaxed text-primary-foreground/80 sm:text-base">
              Get in touch to talk about keeping unavailable products out of your campaigns.
            </p>
          </div>
          <div className="flex shrink-0 flex-col items-start gap-3 sm:items-end">
            <Button
              asChild
              variant="secondary"
              size="lg"
              className="h-12 rounded-sm px-6 transition duration-200 ease-out hover:-translate-y-0.5"
            >
              <Link href="mailto:stockwake-wgwcxq@polsia.app">
                Email Stockwake <ArrowUpRight />
              </Link>
            </Button>
            <Link
              href="mailto:stockwake-wgwcxq@polsia.app"
              className="text-xs text-primary-foreground/80 underline decoration-primary-foreground/40 underline-offset-4 transition-colors hover:text-primary-foreground"
            >
              stockwake-wgwcxq@polsia.app
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
